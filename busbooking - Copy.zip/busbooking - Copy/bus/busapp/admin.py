from django.contrib import admin
from busapp.models import bus
from busapp.models import booking_history
from busapp.models import customer

@ admin.register(bus)
class bus(admin.ModelAdmin):
    list_display=['service_no','start','end','seats_available','price']
    seachfields='service_no'

@ admin.register(booking_history)
class booking_history(admin.ModelAdmin):
    list_display=['ticket_no','customer_id','service_no','no_of_seats','amount']

@ admin.register(customer)
class customer(admin.ModelAdmin):
    list_display=['cid','cname','phono','passw']
