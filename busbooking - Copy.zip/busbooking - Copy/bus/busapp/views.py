from django.shortcuts import render,redirect
from django.http import HttpResponse
from busapp.models import customer,booking_history,bus
from datetime import *
import random

# Create your views here.
def clean_up(request):
    today=int(date('14-03-25'))
    booking=booking_history.objects.filter(travelling_date=today)
    for i in booking:
        delete_booking=i.service_no
        delete_booking.seats_available+=i.no_of_seats
        delete_booking.save()
    booking.delete()
    return HttpResponse('the data is deleeted')

def login(request):
    return render(request,'login.html')

def signup(request):
    return render(request,'signup.html')

def create(request):
    name=request.POST.get('username')
    phno=request.POST.get('phono')
    password=request.POST.get('password')
    cp=request.POST.get('c_p')
    if password==cp:
        a=customer(
            cname=name,
            phono=phno,
            passw=password
        )
        a.save()
        return redirect('/')
    else:
      return redirect('signup')

def verify(request):
    username=request.POST.get('u_n')
    password=request.POST.get('password')
    user=customer.objects.filter(cname=username)
    if user[0].passw==password:
           request.session['n']=username
           details=bus.objects.all()
           return render(request,'home.html',{'bus_details':details})
    else:
            return redirect('/')

def bookbus(request):
    service = request.GET.get('service_no')
    price=request.GET.get('price')
    today=str(date.today())
    return render(request,'booking.html',{'service':service,'price':price,'today':today})

def cancelbus(request):
    return render(request,'cancel.html')

def confirm(request):
    seats=request.POST.get('no.of.seats')
    price=request.POST.get('price')
    service_no=request.POST.get('service no')
    travelling_date=request.POST.get('date')
    amount=int(seats)*int(price)
    customer_name=request.session['n']
    a=bus.objects.filter(service_no=service_no)
    start=a[0].start
    end=a[0].end
    customer_id=customer.objects.filter(cname=customer_name)[0].cid
    customer_instance=customer.objects.get(cid=customer_id)
    bus_instance=bus.objects.get(service_no=service_no)
    tno=f'bus{random.randint(1000,2000)}'
    a=booking_history.objects.create(
        ticket_no=tno,
        customer_id=customer_instance,
        service_no=bus_instance,
        no_of_seats=seats,
        amount=amount,
        travelling_date=travelling_date,
    )
    b=bus.objects.filter(service_no=service_no)[0]
    if b.seats_available>=int(seats):
        b.seats_available-=int(seats)
        b.save()
        return render(request,'ticket.html',{'seats':seats,'service_no':service_no,'amount':amount , 'c_n':customer_name,'from':start,'to':end})
    else:
       return render(request,'booking.html',{'error':f'AVAILABLE SEATS ARE {b.seats_available}PLEASE CHOOSE OTHER SERVICE'})





















